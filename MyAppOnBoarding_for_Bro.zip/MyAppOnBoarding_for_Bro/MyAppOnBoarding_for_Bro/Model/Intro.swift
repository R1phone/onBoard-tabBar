//
//  Intro.swift
//  MyAppOnBoarding_for_Bro
//
//  Created by taneR on 22.10.2023.
//

import SwiftUI

struct Intro: Identifiable {
    var id: String = UUID().uuidString
    var riveFile = String()
    var title: String
    
    
}

var intros: [Intro] = [
    .init(riveFile: "forest", title: "Zaebis'"),

]
let dummyText = "Popitka sdelat' good onBoard mtf!!!"
