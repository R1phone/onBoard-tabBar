//
//  MyAppOnBoarding_for_BroApp.swift
//  MyAppOnBoarding_for_Bro
//
//  Created by taneR on 22.10.2023.
//

import SwiftUI

@main
struct MyAppOnBoarding_for_BroApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
