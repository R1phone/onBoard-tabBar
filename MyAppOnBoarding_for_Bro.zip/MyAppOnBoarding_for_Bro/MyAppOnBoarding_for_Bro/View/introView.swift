//
//  introView.swift
//  MyAppOnBoarding_for_Bro
//
//  Created by taneR on 22.10.2023.
//

import SwiftUI
import RiveRuntime

struct introView: View {
    @State var showWalkThroughScreens: Bool = false
    @State var correntIndex: Int = 0
    @State var showHomeView: Bool = false
    var body: some View {
        ZStack {
            if showHomeView{
                Home()
                    .transition(.move(edge: .trailing))
            }else{
                ZStack {
                     Color("BG")
                        .ignoresSafeArea()
                    IntroScreen()
                    WalkThroughScreens()
                    NavBar()
                    
                }
                .animation(.interactiveSpring(response: 1.1, dampingFraction: 0.85,blendDuration: 0.85), value: showWalkThroughScreens)
                .transition(.move(edge: .leading))
            }
        }
        .animation(.easeOut(duration: 0.35), value: showHomeView)
    }
    
    
   @ViewBuilder
    func WalkThroughScreens()->some View{
        let isLast = correntIndex == intros.count
        
        GeometryReader{
            let size = $0.size
            
            ZStack {
                ForEach(intros.indices, id: \.self) { index in
                    ScreenView(size: size, index: index)
                }
                WelcomeView(size: size, index: intros.count)
                
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .overlay(alignment: .bottom) {
                ZStack {
                    Image(systemName: "chevron.right")
                        .foregroundColor(.white)
                        .font(.title3)
                        .bold()
                        .scaleEffect(!isLast ? 1 : 0.001)
                        .opacity(!isLast ? 1 : 0)
                    HStack {
                        Text("Welcome MtF")
                            .font(.title3)
                            .bold()
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .foregroundColor(.white)

                        Image(systemName: "arrow.right")
                            .font(.title3)
                            .bold()
                            .foregroundColor(.white)

                    }
                    .padding(.horizontal,15)
                    .scaleEffect(isLast ? 1 : 0.001)
                    .frame(height: isLast ? nil : 0)
                    .opacity(isLast ? 1 : 0)
                }
               
                .frame(width: isLast ? size.width / 1.5 : 55,height: isLast ?  50 : 55)
                    .background {
                        RoundedRectangle(cornerRadius: isLast ? 10 : 30,style: isLast ? .continuous:  .circular)
                            .fill(Color.black)
                        
                    }
                    .onTapGesture {
                        if correntIndex == intros.count {
                            showHomeView = true
                        }else{
                            correntIndex += 1

                        }
                    }
                    .offset(y: isLast ? -40 : -25)
                    .animation(.interactiveSpring(response: 0.9, dampingFraction: 0.8, blendDuration: 0.5), value: isLast)
            }
          
            .offset(y: showWalkThroughScreens ? 0 : size.height)
        }
    }
    
    @ViewBuilder
    func ScreenView(size:CGSize, index: Int)->some View {
        let intro = intros[index]
        VStack(spacing: 10){
            Text(intro.title)
                .bold()
                .offset(x: -size.width * CGFloat(correntIndex - index))
                .animation(.interactiveSpring(response: 0.9, dampingFraction: 0.8, blendDuration: 0.5).delay(correntIndex == index ? 0.2 : 0).delay(correntIndex == index ? 0.2 : 0), value: correntIndex)
            Text (dummyText)
                .offset(x: -size.width * CGFloat(correntIndex - index))
                .animation(.interactiveSpring(response: 0.9, dampingFraction: 0.8, blendDuration: 0.5).delay(0.1).delay(correntIndex == index ? 0.2 : 0), value: correntIndex)

            
            RiveViewModel(fileName: "boy").view()
                .ignoresSafeArea()
                .aspectRatio(contentMode: .fill)
                .padding(80)
                .frame(width: size.width, height:580)
                .offset(x: -size.width * CGFloat(correntIndex - index))
                .animation(.interactiveSpring(response: 0.9, dampingFraction: 0.8, blendDuration: 0.5).delay(correntIndex == index ? 0 : 0.2).delay(correntIndex == index ? 0.2 : 0), value: correntIndex)

            
        }
    }
    
    
    @ViewBuilder
    func WelcomeView(size:CGSize, index: Int)->some View {
        VStack(spacing: 10){
            RiveViewModel(fileName: "hands").view()
                .ignoresSafeArea()
                .aspectRatio(contentMode: .fill)
                .padding(10)
                .frame(width: size.width, height:530)
                .offset(x: -size.width * CGFloat(correntIndex - index))
                .animation(.interactiveSpring(response: 0.9, dampingFraction: 0.8, blendDuration: 0.5).delay(correntIndex == index ? 0 : 0.2).delay(correntIndex == index ? 0.1 : 0), value: correntIndex)
            Text("Welcome")
                .bold()
                .padding(3)
                .offset(x: -size.width * CGFloat(correntIndex - index))
                .animation(.interactiveSpring(response: 0.9, dampingFraction: 0.8, blendDuration: 0.5).delay(correntIndex == index ? 0.1 : 0).delay(correntIndex == index ? 0.2 : 0), value: correntIndex)
            Text (dummyText)
                .offset(x: -size.width * CGFloat(correntIndex - index))
                .animation(.interactiveSpring(response: 0.9, dampingFraction: 0.8, blendDuration: 0.5).delay(0.1).delay(correntIndex == index ? 0.2 : 0), value: correntIndex)
               // .padding(10)

        }
        .offset(y: -30)
    }
    
    @ViewBuilder
    func NavBar()->some View{
        let isLast = correntIndex == intros.count
        HStack {
            Button {
                if correntIndex > 0 {
                    correntIndex -= 1
                } else {
                    showWalkThroughScreens.toggle()
                }
            } label: {
                Image(systemName: "chevron.left")
                    .font(.title3)
                    .foregroundColor(.black)
                
                  
                
            }
            Spacer()
            Button("Skip"){
                correntIndex = intros.count
                
                
            }
            .font(.title3)
            .foregroundColor(.black)
            .opacity(isLast ? 0 : 1)
            .animation(.easeOut, value: isLast)
        }
        .padding(.horizontal, 15)
        .padding(.top, 10)
        .frame(maxHeight: .infinity, alignment: .top)
        .offset(y:showWalkThroughScreens ? 0: -120)
    }
    
    
    @ViewBuilder
    func IntroScreen()->some View{
        GeometryReader {
            let size = $0.size
            VStack{
                RiveViewModel(fileName: "shapes").view()
                    .ignoresSafeArea()
                    .aspectRatio(contentMode: .fill)
                    //.padding(10)
                    .frame(width: size.width, height: 680)
                Text ("This is my Best onBoard")
                    .bold()
                   .padding(.top, -10)
                
       
                Text (dummyText)
                    .bold()
                    .multilineTextAlignment(.center)
                    .padding(.horizontal,30)
             //   Spacer()
                Text ("Let's Go")
                    .bold()
                    .padding(.horizontal,30)
                    .padding(.vertical,14)
                    .foregroundColor(.white)
                    .background {
                        Capsule()
                            .fill(Color.black)
                    }
                    .onTapGesture {
                        showWalkThroughScreens.toggle()
                    }
                    .padding(.top,30)
                
                
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
            .offset(y: showWalkThroughScreens ? -size.height : 0)
        }
        .ignoresSafeArea()
    }
}

struct introView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

struct Home: View {
    @State var selected = 0
    @State private var showDtViev = false
    @AppStorage("selectedTab") var selectedTab: Tab = .chat
    let button = RiveViewModel(fileName: "menu_button", stateMachineName: "State Machine", autoPlay: false)
    @State var isOpen = false
    @State var show = false
    var body: some View {
        VStack {
            Spacer ()
            ZStack {
               Color(hex: "17203A").ignoresSafeArea()
                Group {
                    switch selectedTab {
                    case .chat: Text("Chat")
                    case .timer: Text("Timer")
                  // RiveViewModel(fileName: "check",autoPlay: true).view()
                        
                    case .bell: Text("Bell")
                    case .user: Text("User")
                    case .search: Text("Search")
                            .safeAreaInset(edge: .bottom) {
                                Color.clear.frame(height: 80)
                            }
                            .safeAreaInset(edge: .top) {
                                Color.clear.frame(height: 104)
                            }
                            .mask(RoundedRectangle(cornerRadius: 30, style: .continuous))
                            .rotation3DEffect(.degrees(isOpen ? 30 : 0), axis: (x: 0, y: -1, z: 0))
                            .offset(x: isOpen ? 265 : 0)
                            .scaleEffect(isOpen ? 0.9 : 1)
                            .scaleEffect(show ? 0.92 : 1)
                            .ignoresSafeArea()
                    
                            TabBar()
                                .offset(y: isOpen ? 300 : 0)
                                .offset(y: show ? 200 : 0)
                    }
                }
              HStack {
                    TabBar()
                        .background(BG())
                       
                    /*
                     Button (action: {
                     self.selected = 0
                     }) {
                     Image (systemName: "figure.roll.runningpace")
                     } .foregroundColor(self.selected == 0 ? .black : .green)
                     
                     
                     Spacer (minLength: 12)
                     
                     Button (action: {
                     self.selected = 1
                     }) {
                     Image (systemName: "figure.archery")
                     } .foregroundColor(self.selected == 1 ? .black : .green)
                     
                     
                     Spacer () .frame(width: 120)
                     
                     Button (action: {
                     self.selected = 2
                     
                     }) {
                     Image (systemName: "figure.australian.football")
                     
                     } .foregroundColor(self.selected == 2 ? .black : .green)
                     Spacer (minLength: 12)
                     Button (action: {
                     self.selected = 3
                     }) {
                     Image (systemName: "figure.baseball")
                     } .foregroundColor(self.selected == 3 ? .black : .green)
                     }
                     .padding()
                     .padding(.horizontal, 23)
                     // .background(Color.white)
                     .background(Shape())
                     
                     Button (action: {
                     self.showDtViev.toggle()
                     }) {
                     Image (systemName: "medal.fill")
                     .renderingMode(.original)
                     .padding(20)
                     
                     }
                     // .foregroundColor(.white)
                     .background(Color.yellow)
                     .clipShape(Circle())
                     .offset(y: -30)
                     .shadow(radius: 7)
                     } .sheet (isPresented: $showDtViev) {
                     DtViev ()
                     }
                     } .background(BG())
                     */
                }
            }
        }
    }
}

struct Shape: View {
    var body: some View {
        Path { path in
            path.move(to: CGPoint (x: 0, y: 0))
            path.addLine(to: CGPoint(x: UIScreen.main.bounds.width, y: 0))
            path.addLine(to: CGPoint(x: UIScreen.main.bounds.width, y: 55))
            //  path.move(to: CGPoint (x: 0, y: 0)) OLEN' Ya(
            
            
            path.addArc(center: CGPoint ( x: UIScreen.main.bounds.width / 2, y: 55),
                        radius: 33, startAngle: .zero, endAngle: .init(degrees: 180), clockwise: true)
            path.addLine(to: CGPoint(x: 0, y: 55))
            
        } .fill(Color.white)
            .rotationEffect(.init(degrees: 180))
    }
}

   
struct DtViev: View {
    var body: some View{
        RiveViewModel(fileName: "wine").view()
    }
}

struct BG : View {
    @GestureState var location: CGPoint = .zero
    var body: some View {
        GeometryReader { proxy in
            let size = proxy.size
            let with = (size.width / 10)
            let itemCount = Int((size.height / with ).rounded()) * 10
            
            
                LinearGradient(colors: [
                    .black, .red, .mint, .pink, .purple, .green
                ], startPoint: .topLeading, endPoint: .bottomTrailing)
                .mask {
                    LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 0), count: 10), spacing: 0) {
                        ForEach(0..<itemCount, id: \.self) {_ in
                            GeometryReader {InnerProxy in
                                let rect = InnerProxy.frame(in: .named("GESTURE"))
                                let scale = itemScale(rect: rect, size: size)
                                
                                RoundedRectangle (cornerRadius: 4)
                                    .fill(.green)
                                    .scaleEffect(scale)
                                
                            }
                            .frame(height: with)
                            .padding(5)
                        }
                    
                    }
                }
                
            }
        
        
        .padding(15)
        .gesture(
            DragGesture(minimumDistance: 0)
                .updating($location, body:  {  value, out, _ in
                    out = value.location
                })
            
            
        )
        .coordinateSpace(name: "GESTURE")
        .preferredColorScheme(.dark)
        .animation(.easeOut, value: location == .zero)
        
    }
    
    
    func itemScale (rect: CGRect, size: CGSize)-> CGFloat {
        let a = location.x - rect.midX
        let b = location.y - rect.midY
        
        let root = sqrt((a * a) + (b * b))
        let diagonalView = sqrt((size.width * size.width) + (size.height * size.height))
        
        let scale = root / (diagonalView / 2)
        let modifiedScale = location == .zero ? 1 : (1 - scale)
        
        
        //return scale
        return modifiedScale > 0 ? modifiedScale : 0.001
        
    }
}
